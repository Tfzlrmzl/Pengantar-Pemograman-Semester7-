PRAKTIK PEMROGRAMAN JAVA - BAGIAN C
===================================

Isi folder:
1. ProgramBiodataMahasiswa.java
2. MenentukanGanjilGenap.java
3. MenentukanNilaiHuruf.java
4. PerulanganBilangan.java
5. MenghitungRataRataNilai.java

Cara menjalankan:
- Buka NetBeans, buat Java Application, lalu buat class sesuai nama file.
- Salin isi file .java ke class dengan nama yang sama.
- Jalankan (Run File / Shift+F6).

Alternatif melalui terminal:
javac ProgramBiodataMahasiswa.java
java ProgramBiodataMahasiswa

Ulangi perintah javac/java dengan nama class program lain.
Catatan: Setiap program berdiri sendiri dan tidak menggunakan deklarasi package.
