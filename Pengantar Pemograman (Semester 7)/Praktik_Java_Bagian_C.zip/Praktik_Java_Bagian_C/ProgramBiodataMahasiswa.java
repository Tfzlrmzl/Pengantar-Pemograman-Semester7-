import java.util.Scanner;

public class ProgramBiodataMahasiswa {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("=== BIODATA MAHASISWA ===");

        System.out.print("Masukkan nama       : ");
        String nama = input.nextLine();

        System.out.print("Masukkan NIM        : ");
        String nim = input.nextLine();

        System.out.print("Masukkan program studi: ");
        String programStudi = input.nextLine();

        System.out.print("Masukkan semester   : ");
        int semester = input.nextInt();

        System.out.print("Masukkan IPK         : ");
        double ipk = input.nextDouble();

        System.out.println("\n=== DATA MAHASISWA ===");
        System.out.println("Nama         : " + nama);
        System.out.println("NIM          : " + nim);
        System.out.println("Program Studi: " + programStudi);
        System.out.println("Semester     : " + semester);
        System.out.printf("IPK          : %.2f%n", ipk);

        input.close();
    }
}
